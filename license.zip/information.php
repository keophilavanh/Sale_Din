
<html lang="en">
<head>
    <meta charset="utf-8">
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> -->

    <?php include 'src.php';   ?>

  
</head>


<body class="bg-light">

<?php 
 $fix="fixed-top";
    include 'header.php'; 

?>

        

<div class="d-flex">
    
   

    <div class="content p-4 mt-5">
        
        
            <div class="container mt-5">
            
                            <!-- <h1>Information</h1><br/> -->
                <div class="col-sm-2"> 
            
                </div>
                <div class="col-sm-10" class="row" id="itemlist"> 
                    
                        <!-- <div class="bg-white box mb-4 " >
                            <img  style="width: 100%; height: 400px;" src="https://s3-ap-southeast-1.amazonaws.com/yula/public/listing/2020/03/26/AujEAEHzZa7aJhu5lD0SKbytiUZLr2MNGscIyMK2.jpeg" alt="First slide"><br/>
                            <div class="col-sm-12 ">
                                <br/>
                                <h5>Apr. 28, 2020, 12:06 pm. </h5>
                                <h4 > &nbsp;&nbsp; ອາພາດເມັນໃນຕົວເມືອງວຽງຈັນແຫ່ງໃໝ່ (VLC): ພັກອາໄສ, ເຮັດວຽກ ແລະ ທ່ຽວຫຼິ້ນໄດ້ທີ່ ສູນກາງທີ່ຢູ່ອາໄສ </h4><br/>

                                <p class=" multi-line-truncate" style="width: 95%; height: 80px;" > &nbsp;&nbsp; VLC ມີທຳເລທີ່ຕັ້ງທີ່ດີທີ່ສຸດໃນເຂດທຸລະກິດໃຈກາງນະຄອນຫຼວງວຽງຈັນ, ສູນການຄ້າວຽງຈັນເຊັນເຕີ, ໃກ້ຄຽງກັບບັນດາກະຊວງ ແລະ ສະຖານທູດຕ່າງໆ. ນອກນັ້ນຍັງໃກ້ກັບຮ້ານອາຫານ, ຮ້ານບັນເທິງທີ່ມີທັງສະໄຕລລາວ ແລະ ຕ່າງປະເທດ. ລວມທັງສູນການຄ້າປາກເຊີນ, ຕະຫຼາດເຊົ້າ, ແລະ ບັນດາຮ້ານຕ່າງໆອີກຫຼາຍຮ້ອຍແຫ່ງ. ສະຖານທີ່ສາມາດຈັບຈອງໄດ້ທັງຄົນລາວ ແລະ ຄົນຕ່າງປະເທດໂດຍມີອາຍຸການເຊົ່າເຖິງ 70 ປີ ເຊິ່ງໝັ້ນໃຈໄດ້ເລີຍວ່າທ່ານຈະໄດ້ທຶນຄືນ 6% ຈາກການເຊົ່າພຽງແຕ່ 10 ປີ. ນັ້ນໝາຍຄວາມວ່າພາຍຫຼັງ 10 ປີທີ່ເປັນເຈົ້າຂອງແມ່ນທ່ານຈະໄດ້ຮັບທຶນຄືນ 60% ຈາກການລົງທຶນ. </p>
                            </div>

                        </div> -->

                        <div class="bg-white box mb-4" style="height: 200px;" >
                                <div class="row" >

                                    <div class="col-sm-4 " >
                                        <img  style="width: 250px; height: 200px;"   src="https://s3-ap-southeast-1.amazonaws.com/yula/public/listing/2020/03/26/AujEAEHzZa7aJhu5lD0SKbytiUZLr2MNGscIyMK2.jpeg" alt="First slide"><br/>
                                    </div >
                                    <div class="col-sm-8 " >
                                        
                                        <h5 class="mt-3 text-truncate"  > ອາພາດເມັນໃນຕົວເມືອງວຽງຈັນແຫ່ງໃໝ່ (VLC): ພັກອາໄສ, ເຮັດວຽກ ແລະ ທ່ຽວຫຼິ້ນໄດ້ທີ່ ສູນກາງທີ່ຢູ່ອາໄສ </h5>
                                        <p>Apr. 28, 2020, 12:06 PM </p>
                                        
                                        <p  class=" multi-line-truncate" style="width: 95%; height: 80px;" >VLC ມີທຳເລທີ່ຕັ້ງທີ່ດີທີ່ສຸດໃນເຂດທຸລະກິດໃຈກາງນະຄອນຫຼວງວຽງຈັນ, ສູນການຄ້າວຽງຈັນເຊັນເຕີ, ໃກ້ຄຽງກັບບັນດາກະຊວງ ແລະ ສະຖານທູດຕ່າງໆ. ນອກນັ້ນຍັງໃກ້ກັບຮ້ານອາຫານ, ຮ້ານບັນເທິງທີ່ມີທັງສະໄຕລລາວ ແລະ ຕ່າງປະເທດ. ລວມທັງສູນການຄ້າປາກເຊີນ, ຕະຫຼາດເຊົ້າ, ແລະ ບັນດາຮ້ານຕ່າງໆອີກຫຼາຍຮ້ອຍແຫ່ງ.
                        ສະຖານທີ່ສາມາດຈັບຈອງໄດ້ທັງຄົນລາວ ແລະ ຄົນຕ່າງປະເທດໂດຍມີອາຍຸການເຊົ່າເຖິງ 70 ປີ ເຊິ່ງໝັ້ນໃຈໄດ້ເລີຍວ່າທ່ານຈະໄດ້ທຶນຄືນ 6% ຈາກການເຊົ່າພຽງແຕ່ 10 ປີ. ນັ້ນໝາຍຄວາມວ່າພາຍຫຼັງ 10 ປີທີ່ເປັນເຈົ້າຂອງແມ່ນທ່ານຈະໄດ້ຮັບທຶນຄືນ 60% ຈາກການລົງທຶນ.</p>

                                    </div>

                                </div >
                        </div>
                        
                    
            
                </div>
                <div class="col-sm-2"> 
                
                </div>
            </div>   
               

            

           
                

            
            <div class="container text-center" id="pagination" style="width: 75%;"> 
                <!-- <a href="#" class="btn btn-dark btn-lg btn-square">Previous</a>
                <a href="#" class="btn btn-dark btn-lg btn-square">1</a>
                <a href="#" class="btn btn-dark btn-lg btn-square">2</a>
                <a href="#" class="btn btn-dark btn-lg btn-square">3</a>
                <a href="#" class="btn btn-dark btn-lg btn-square">4</a>
                <a href="#" class="btn btn-dark btn-lg btn-square">5</a>
                <a href="#" class="btn btn-dark btn-lg btn-square">Next</a> -->
            </div>

        </div>
        <?php include 'search.php'; ?>
    </div>






</body>
</html>

<script>

        $(document).ready(function () {

            $('#search').click(function () {
               
               $('#add_data_Modal').modal('show');
               $('#insert_form')[0].reset();
            
                 
           });

            function load_parameter(){
                const queryString = window.location.search;
                const urlParams = new URLSearchParams(queryString);
                const product = urlParams.get('page');
                if(product){
                    return product;
                }else{
                    return 1;
                }
            }

            $(document).on('click', '.item_detell', function(){  
               

               var product_id = $(this).attr("id");  

               console.log(product_id);
               window.location.replace('information_detell.php?information_id='+product_id);

           });


            
            $.ajax({
                    url:"php/information/pagination/pagination.php",
                    method:"POST",
                    dataType:"json",
                    data:{page:load_parameter()},  
                    success:function(data){
                   
                        $('#itemlist').html(data.itemlist);
                        $('#pagination').html(data.pagination);
                        console.log(data);

                    }
                });
            
           

        });

</script>



