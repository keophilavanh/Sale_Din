<?php 
    $src = '    <link rel="stylesheet" href="css/bootstrap.min.css">
                <link rel="stylesheet" href="css/fontawesome-all.min.css">
                <link rel="stylesheet" href="css/bootadmin.min.css">
                <link rel="stylesheet" href="font-face/stylesheet.css">
                <link rel="stylesheet" href="css/datatables.min.css">
                <link rel="stylesheet" href="css/jquery.toast.css">
                <link rel="stylesheet" href="css/item.css">
                <link rel="stylesheet" href="css/footer.css">
                <link rel="stylesheet" href="css/jquery.datetimepicker.min.css">
            

                

                <script src="js/jquery.js"></script>
                <script src="js/bootstrap.bundle.min.js"></script>
                <script src="js/bootadmin.min.js"></script>
                <script src="js/datatables.min.js"></script>
                <script src="js/sweetalert.min.js"></script>
                <script src="js/jquery.toast.js"></script>
                <script src="js/jquery.datetimepicker.full.js"></script>
                <script src="js/translate.js"></script>

                <link rel="icon" href="http://via.placeholder.com/350x150" type="image/png" id="icon" sizes="16x16">
                <title id="title_web"> Sale </title> ';
    echo $src;
?>