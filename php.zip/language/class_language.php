<?php

class language {
    // Properties
    public $home;
    public $category;
    public $infomation;
    public $aboue;
    public $profile;
    public $logout;

    public $login;
    public $titel_login;
    public $button_login;
    public $button_Register;
    
    public $menu_inbox;
    public $menu_product_list;
  }

?>